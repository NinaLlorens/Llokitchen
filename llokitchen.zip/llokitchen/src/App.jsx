import { useState, useEffect, useRef, useCallback } from "react";

const KEY = "llokitchen_v4";
const load = () => { try { const r = localStorage.getItem(KEY); return r ? JSON.parse(r) : null; } catch { return null; } };
const persist = (d) => { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch {} };
const DEFAULT = { items: [], shopping: [], theme: "light", profile: null };

const STORAGES = [
  { id: "frigo", label: "Frigo", icon: "❄️" },
  { id: "congelateur", label: "Congélo", icon: "🧊" },
  { id: "placards", label: "Placards", icon: "🗄️" },
];
const CATS = [
  { id: "proteines", label: "Protéines", icon: "🥩", bg: "#FFF0ED", dark: "#2A1410", accent: "#E8614A" },
  { id: "glucides",  label: "Glucides",  icon: "🌾", bg: "#FFF8E6", dark: "#2A1E06", accent: "#C8860A" },
  { id: "lipides",   label: "Lipides",   icon: "🧈", bg: "#FFFBE6", dark: "#2A2206", accent: "#B8940A" },
  { id: "legumes",   label: "Légumes",   icon: "🥦", bg: "#EDFAF3", dark: "#091E12", accent: "#2A8A52" },
  { id: "laitiers",  label: "Laitiers",  icon: "🥛", bg: "#EEF4FF", dark: "#0E1628", accent: "#3A6BD4" },
  { id: "autres",    label: "Autres",    icon: "🫙", bg: "#F5F0FF", dark: "#160A2A", accent: "#7C4DD4" },
];
const QTYS = ["trace", "peu", "moyen", "beaucoup", "plein"];
const getcat = (id) => CATS.find(c => c.id === id) || CATS[5];

function daysLeft(item) {
  if (!item.emptyDate) return null;
  return Math.ceil((new Date(item.emptyDate) - new Date()) / 86400000);
}
function getAlerts(items) {
  return items.map(i => ({ ...i, dl: daysLeft(i) }))
    .filter(i => i.dl !== null && i.dl <= 4 && i.dl >= 0)
    .sort((a, b) => a.dl - b.dl);
}

async function aiJSON(system, user, max = 900) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: max, system, messages: [{ role: "user", content: user }] })
  });
  const d = await res.json();
  const txt = d.content?.find(b => b.type === "text")?.text || "";
  return JSON.parse(txt.replace(/```json[\s\S]*?```|```/g, "").trim());
}

const LT = {
  bg: "#FAF7F2", surface: "#FFFFFF", s2: "#F3EFE8", s3: "#EDE8DF",
  border: "rgba(0,0,0,0.06)", text: "#1A1612", t2: "#7A7068", t3: "#AEA49A",
  accent: "#3D9E5C", accentDk: "#2A7040", accentBg: "rgba(61,158,92,0.1)",
  orange: "#D96020", orangeBg: "rgba(217,96,32,0.1)",
  red: "#D03028", blue: "#2A62C8", blueBg: "rgba(42,98,200,0.09)",
  sh: "0 2px 12px rgba(0,0,0,0.07)", shMd: "0 8px 28px rgba(0,0,0,0.1)",
};
const DK = {
  bg: "#12100E", surface: "#1E1C18", s2: "#2A2720", s3: "#343028",
  border: "rgba(255,255,255,0.07)", text: "#F2EDE6", t2: "#9A9288", t3: "#6A6258",
  accent: "#4CAF6F", accentDk: "#2D8A4E", accentBg: "rgba(76,175,111,0.12)",
  orange: "#E8722A", orangeBg: "rgba(232,114,42,0.12)",
  red: "#E04838", blue: "#4A8AE8", blueBg: "rgba(74,138,232,0.12)",
  sh: "0 2px 12px rgba(0,0,0,0.4)", shMd: "0 8px 28px rgba(0,0,0,0.5)",
};

export default function LloKitchen() {
  const [data, setData] = useState(() => load() || DEFAULT);
  const [tab, setTab] = useState("home");
  const [dark, setDark] = useState(() => {
    const d = load(); if (!d) return false;
    if (d.theme === "dark") return true; if (d.theme === "light") return false;
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
  });
  const T = dark ? DK : LT;

  // onboarding
  const [showOnboard, setShowOnboard] = useState(false);
  const [onboardName, setOnboardName] = useState("");

  // voice — FIX: use a single ref that persists
  const srRef = useRef(null);
  const [listening, setListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [voiceText, setVoiceText] = useState("");
  const [voiceParsed, setVoiceParsed] = useState(null);
  const [voiceStep, setVoiceStep] = useState("idle"); // idle|listening|parsing|confirm

  // consume modal
  const [consumeList, setConsumeList] = useState([]);
  const [showConsumeModal, setShowConsumeModal] = useState(false);

  // meals
  const [meals, setMeals] = useState([]);
  const [mealsLoading, setMealsLoading] = useState(false);
  const [mealIdx, setMealIdx] = useState(0);
  const [activeMeal, setActiveMeal] = useState(null);
  const [mealRecipe, setMealRecipe] = useState(null);
  const [mealRecipeLoading, setMealRecipeLoading] = useState(false);

  // stock
  const [stor, setStor] = useState("frigo");
  const [fcat, setFcat] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const [newItem, setNewItem] = useState({ name: "", category: "proteines", quantity: "moyen", storage: "frigo", emptyDate: "" });

  // recettes
  const [rPersons, setRPersons] = useState(2);
  const [rType, setRType] = useState("rapide");
  const [rRecipe, setRRecipe] = useState(null);
  const [rLoading, setRLoading] = useState(false);

  // courses
  const [shopInput, setShopInput] = useState("");
  const [shopSugg, setShopSugg] = useState([]);
  const [shopSuggLoading, setShopSuggLoading] = useState(false);

  useEffect(() => { persist(data); }, [data]);

  // Check SR support once
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR) setVoiceSupported(true);
  }, []);

  // Create a fresh SR instance each time — fixes Safari iOS stop() bug
  const createSR = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;
    const r = new SR();
    r.lang = "fr-FR"; r.continuous = false; r.interimResults = false;
    r.onresult = (e) => {
      const text = e.results[0][0].transcript;
      srRef.current = null;
      setListening(false);
      setVoiceText(text);
      setVoiceStep("parsing");
    };
    r.onend = () => {
      setListening(false);
    };
    r.onerror = (e) => {
      srRef.current = null;
      setListening(false);
      if (e.error !== "aborted") setVoiceStep("idle");
    };
    return r;
  };

  // When voiceText changes and we're parsing, call AI
  const namesRef = useRef("");
  namesRef.current = data.items.map(i => i.name).join(", ") || "vide";

  useEffect(() => {
    if (voiceStep !== "parsing" || !voiceText) return;
    (async () => {
      try {
        const p = await aiJSON(
          `Analyse ce texte dicté en français. JSON uniquement.
Format: {"action":"add"|"consume"|"mixed","add":[{"name":"...","category":"proteines|glucides|lipides|legumes|laitiers|autres","quantity":"trace|peu|moyen|beaucoup|plein","storage":"frigo|congelateur|placards"}],"consume":[{"name":"..."}]}
add = acheter/avoir. consume = manger/finir/utiliser. Stock existant: ${namesRef.current}`,
          voiceText
        );
        setVoiceParsed(p); setVoiceStep("confirm");
      } catch { setVoiceStep("idle"); }
    })();
  }, [voiceStep, voiceText]);

  const startVoice = () => {
    const r = createSR();
    if (!r) return;
    srRef.current = r;
    setVoiceStep("listening"); setVoiceText(""); setVoiceParsed(null);
    setListening(true);
    try { r.start(); } catch(e) { setListening(false); setVoiceStep("idle"); }
  };

  const stopVoice = () => {
    if (srRef.current) {
      try { srRef.current.abort(); } catch(e) {}
      srRef.current = null;
    }
    setListening(false);
    // If we stopped manually without a result, go back to idle
    setVoiceStep(prev => prev === "listening" ? "idle" : prev);
  };

  const cancelVoice = () => { stopVoice(); setVoiceStep("idle"); setVoiceText(""); setVoiceParsed(null); };

  const confirmVoice = () => {
    if (!voiceParsed) return;
    if (voiceParsed.add?.length) setData(d => ({ ...d, items: [...d.items, ...voiceParsed.add.map(i => ({ ...i, id: Date.now() + Math.random() }))] }));
    if (voiceParsed.consume?.length) { setConsumeList(voiceParsed.consume); setShowConsumeModal(true); }
    setVoiceStep("idle"); setVoiceParsed(null); setVoiceText("");
  };

  const doConsume = (addCourses) => {
    const ns = consumeList.map(c => c.name.toLowerCase());
    setData(d => ({
      ...d,
      items: d.items.filter(i => !ns.some(n => i.name.toLowerCase().includes(n))),
      shopping: addCourses ? [...d.shopping, ...consumeList.map(c => ({ id: Date.now() + Math.random(), name: c.name, checked: false }))] : d.shopping,
    }));
    setShowConsumeModal(false); setConsumeList([]);
  };

  const addShop = (name = shopInput.trim()) => {
    if (!name) return;
    setData(d => ({ ...d, shopping: [...d.shopping, { id: Date.now(), name, checked: false }] }));
    setShopInput("");
  };
  const toggleShop = (id) => setData(d => ({ ...d, shopping: d.shopping.map(i => i.id === id ? { ...i, checked: !i.checked } : i) }));
  const removeShop = (id) => setData(d => ({ ...d, shopping: d.shopping.filter(i => i.id !== id) }));
  const addItem = () => {
    if (!newItem.name.trim()) return;
    setData(d => ({ ...d, items: [...d.items, { ...newItem, id: Date.now(), name: newItem.name.trim() }] }));
    setNewItem({ name: "", category: "proteines", quantity: "moyen", storage: stor, emptyDate: "" });
    setShowAdd(false);
  };
  const removeItem = (id) => setData(d => ({ ...d, items: d.items.filter(i => i.id !== id) }));

  const summary = () => data.items.map(i => `${i.name}(${i.quantity},${i.storage})`).join(", ") || "vide";

  const cycleTheme = () => {
    const nd = !dark;
    setDark(nd);
    setData(d => ({ ...d, theme: nd ? "dark" : "light" }));
  };

  const alerts = getAlerts(data.items);
  const filtered = data.items.filter(i => i.storage === stor && (fcat === "all" || i.category === fcat));

  useEffect(() => {
    if (!data.profile) { setShowOnboard(true); return; }
    document.title = "Llo Kitchen";
    if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
  }, [data.profile]);

  // ── ONBOARDING ─────────────────────────────────────────────────────────────
  if (showOnboard) return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg, #4CAF6F 0%, #2D6A8E 100%)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "40px 24px", fontFamily: "Georgia, serif" }}>
      <div style={{ fontSize: 64, marginBottom: 12 }}>🍃</div>
      <div style={{ fontSize: 36, fontWeight: 900, color: "#fff", letterSpacing: "-1px", marginBottom: 4, textAlign: "center" }}>Llo Kitchen</div>
      <div style={{ fontSize: 15, color: "rgba(255,255,255,0.75)", marginBottom: 40, textAlign: "center" }}>Votre cuisine intelligente</div>
      <div style={{ background: "#fff", borderRadius: 28, padding: "32px 24px", width: "100%", maxWidth: 360, boxShadow: "0 20px 60px rgba(0,0,0,0.2)" }}>
        <div style={{ fontFamily: "Georgia, serif", fontWeight: 800, fontSize: 22, color: "#1A1612", marginBottom: 6 }}>Qui êtes-vous ?</div>
        <div style={{ fontSize: 14, color: "#7A7068", marginBottom: 24 }}>Pour personnaliser votre expérience</div>
        <div style={{ display: "flex", gap: 12, marginBottom: 20 }}>
          {["Nina", "Jonathan"].map(name => (
            <button key={name} onClick={() => setOnboardName(name)} style={{
              flex: 1, padding: "16px 8px", borderRadius: 18, border: `2px solid`,
              borderColor: onboardName === name ? "#3D9E5C" : "#EDE8DF",
              background: onboardName === name ? "rgba(61,158,92,0.07)" : "#FAF7F2",
              cursor: "pointer", transition: "all 0.2s",
            }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>{name === "Nina" ? "👩" : "👨"}</div>
              <div style={{ fontWeight: 800, fontSize: 15, color: onboardName === name ? "#2A7040" : "#1A1612" }}>{name}</div>
            </button>
          ))}
        </div>
        <div style={{ textAlign: "center", fontSize: 12, color: "#AEA49A", marginBottom: 14 }}>ou entrez un autre prénom</div>
        <input value={onboardName} onChange={e => setOnboardName(e.target.value)} placeholder="Votre prénom…"
          style={{ width: "100%", padding: "13px 16px", borderRadius: 14, border: "2px solid #EDE8DF", background: "#FAF7F2", fontSize: 15, color: "#1A1612", outline: "none", boxSizing: "border-box", marginBottom: 20 }} />
        <button onClick={() => { if (!onboardName.trim()) return; setData(d => ({ ...d, profile: onboardName.trim() })); setShowOnboard(false); }} style={{
          width: "100%", padding: "15px", borderRadius: 16, border: "none",
          cursor: onboardName.trim() ? "pointer" : "not-allowed",
          background: onboardName.trim() ? "linear-gradient(135deg, #4CAF6F, #2D8A4E)" : "#EDE8DF",
          color: onboardName.trim() ? "#fff" : "#AEA49A",
          fontWeight: 800, fontSize: 16,
          boxShadow: onboardName.trim() ? "0 8px 24px rgba(76,175,111,0.4)" : "none",
        }}>Commencer →</button>
      </div>
    </div>
  );

  // ── SHARED UI ──────────────────────────────────────────────────────────────
  const SL = ({ children }) => <div style={{ fontSize: 11, fontWeight: 800, color: T.t2, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10 }}>{children}</div>;
  const RCard = ({ children, style = {} }) => <div style={{ background: T.surface, borderRadius: 20, overflow: "hidden", boxShadow: T.sh, border: `1px solid ${T.border}`, ...style }}>{children}</div>;

  // ── VOICE PANEL ────────────────────────────────────────────────────────────
  const VoicePanel = () => (
    <div style={{ background: dark ? T.s2 : "#EFF9F3", borderRadius: 24, padding: "22px 20px", marginBottom: 24, border: `1px solid ${dark ? T.border : "rgba(61,158,92,0.2)"}` }}>
      {voiceStep === "idle" && (
        <div style={{ textAlign: "center" }}>
          <button
            onClick={voiceSupported ? startVoice : undefined}
            style={{ width: 76, height: 76, borderRadius: "50%", border: "none", cursor: voiceSupported ? "pointer" : "not-allowed", background: "linear-gradient(145deg, #4CAF6F, #2A7040)", boxShadow: "0 8px 28px rgba(76,175,111,0.45)", fontSize: 30, display: "inline-flex", alignItems: "center", justifyContent: "center" }}
          >🎙️</button>
          <div style={{ fontSize: 14, fontWeight: 700, color: T.accentDk, marginTop: 10 }}>{voiceSupported ? "Dicte ton stock" : "Disponible sur Safari iOS"}</div>
          <div style={{ fontSize: 12, color: T.t2, marginTop: 4, lineHeight: 1.6 }}>"J'ai acheté du lait" · "On a mangé les pâtes"</div>
        </div>
      )}

      {voiceStep === "listening" && (
        <div style={{ textAlign: "center" }}>
          <button onClick={stopVoice} style={{ width: 76, height: 76, borderRadius: "50%", border: "none", cursor: "pointer", background: "linear-gradient(145deg, #D03028, #A01818)", boxShadow: "0 8px 28px rgba(208,48,40,0.45)", fontSize: 28, display: "inline-flex", alignItems: "center", justifyContent: "center", animation: "pulse 1.2s ease-in-out infinite" }}>🔴</button>
          <div style={{ fontSize: 14, fontWeight: 700, color: T.red, marginTop: 10 }}>À l'écoute… parle !</div>
          <div style={{ fontSize: 12, color: T.t2, marginTop: 4 }}>Appuie pour arrêter</div>
        </div>
      )}

      {voiceStep === "parsing" && (
        <div style={{ textAlign: "center", padding: "8px 0" }}>
          <div style={{ fontSize: 34, marginBottom: 8 }}>✨</div>
          <div style={{ fontSize: 14, color: T.t2 }}>J'analyse ce que tu as dit…</div>
        </div>
      )}

      {voiceStep === "confirm" && voiceParsed && (
        <div>
          <div style={{ fontSize: 13, color: T.t2, fontStyle: "italic", background: T.s2, padding: "10px 14px", borderRadius: 12, marginBottom: 16, lineHeight: 1.5 }}>"{voiceText}"</div>
          {voiceParsed.add?.length > 0 && (
            <div style={{ marginBottom: 14 }}>
              <SL>✅ À ajouter</SL>
              {voiceParsed.add.map((item, i) => {
                const c = getcat(item.category);
                return <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: 14, background: dark ? c.dark : c.bg, marginBottom: 8 }}>
                  <span style={{ fontSize: 18 }}>{c.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, color: T.text }}>{item.name}</div>
                    <div style={{ fontSize: 11, color: T.t2 }}>{item.quantity} · {item.storage}</div>
                  </div>
                </div>;
              })}
            </div>
          )}
          {voiceParsed.consume?.length > 0 && (
            <div style={{ marginBottom: 14 }}>
              <SL>🍽️ À retirer</SL>
              {voiceParsed.consume.map((item, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: 14, background: T.orangeBg, marginBottom: 8 }}>
                  <span style={{ fontSize: 18 }}>🍴</span>
                  <div style={{ fontWeight: 700, fontSize: 14, color: T.text }}>{item.name}</div>
                </div>
              ))}
            </div>
          )}
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={cancelVoice} style={{ flex: 1, padding: "12px", borderRadius: 14, border: "none", cursor: "pointer", background: T.s2, color: T.t2, fontWeight: 700, fontSize: 14 }}>Annuler</button>
            <button onClick={confirmVoice} style={{ flex: 2, padding: "12px", borderRadius: 14, border: "none", cursor: "pointer", background: "linear-gradient(135deg, #4CAF6F, #2A7040)", color: "#fff", fontWeight: 800, fontSize: 14, boxShadow: "0 4px 14px rgba(76,175,111,0.4)" }}>Confirmer ✓</button>
          </div>
        </div>
      )}
    </div>
  );

  // ── MODALS ─────────────────────────────────────────────────────────────────
  const ConsumeModal = () => (
    <div style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.5)", backdropFilter: "blur(12px)", display: "flex", alignItems: "flex-end" }}>
      <div style={{ background: T.surface, borderRadius: "28px 28px 0 0", width: "100%", padding: "32px 24px 44px" }}>
        <div style={{ fontFamily: "Georgia, serif", fontWeight: 800, fontSize: 22, color: T.text, marginBottom: 8 }}>Vous avez mangé ça ? 🍽️</div>
        <div style={{ fontSize: 14, color: T.t2, marginBottom: 20, lineHeight: 1.6 }}>Je vais retirer ces aliments. Voulez-vous aussi les ajouter aux courses ?</div>
        {consumeList.map((item, i) => <div key={i} style={{ padding: "12px 16px", background: T.s2, borderRadius: 14, marginBottom: 10, fontWeight: 700, color: T.text, fontSize: 15 }}>🍴 {item.name}</div>)}
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 8 }}>
          <button onClick={() => doConsume(true)} style={{ padding: "15px", borderRadius: 16, border: "none", cursor: "pointer", background: "linear-gradient(135deg, #4CAF6F, #2A7040)", color: "#fff", fontWeight: 800, fontSize: 15, boxShadow: "0 6px 16px rgba(76,175,111,0.4)" }}>Retirer + ajouter aux courses 🛒</button>
          <button onClick={() => doConsume(false)} style={{ padding: "15px", borderRadius: 16, border: "none", cursor: "pointer", background: T.s2, color: T.t2, fontWeight: 700, fontSize: 15 }}>Juste retirer du stock</button>
        </div>
      </div>
    </div>
  );

  const MealModal = () => (
    <div style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.55)", backdropFilter: "blur(12px)", display: "flex", alignItems: "flex-end" }}>
      <div style={{ background: T.bg, borderRadius: "28px 28px 0 0", width: "100%", maxHeight: "92vh", overflowY: "auto", paddingBottom: 44 }}>
        <div style={{ padding: "20px 20px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: T.bg, borderBottom: `1px solid ${T.border}` }}>
          <div style={{ fontFamily: "Georgia, serif", fontWeight: 800, fontSize: 18, color: T.text }}>{activeMeal?.emoji} {activeMeal?.titre}</div>
          <button onClick={() => { setActiveMeal(null); setMealRecipe(null); }} style={{ width: 34, height: 34, borderRadius: 12, border: "none", cursor: "pointer", background: T.s2, color: T.t2, fontSize: 18 }}>✕</button>
        </div>
        {mealRecipeLoading && <div style={{ textAlign: "center", padding: 48, color: T.t2 }}><div style={{ fontSize: 32, marginBottom: 10 }}>⏳</div>Génération…</div>}
        {mealRecipe && !mealRecipe.error && (
          <div style={{ padding: "20px" }}>
            <div style={{ fontSize: 13, color: T.t2, marginBottom: 16 }}>⏱ {mealRecipe.temps}</div>
            {mealRecipe.equilibre && (
              <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
                {Object.entries(mealRecipe.equilibre).map(([k, v]) => (
                  <div key={k} style={{ flex: 1, padding: "12px 6px", background: T.surface, borderRadius: 14, textAlign: "center", border: `1px solid ${T.border}` }}>
                    <div style={{ fontSize: 10, fontWeight: 800, color: T.accent, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 4 }}>{k}</div>
                    <div style={{ fontSize: 12, color: T.t2 }}>{v}</div>
                  </div>
                ))}
              </div>
            )}
            <SL>Ingrédients</SL>
            <div style={{ marginBottom: 20 }}>
              {(mealRecipe.ingredients || []).map((ing, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: `1px solid ${T.border}` }}>
                  <span>{ing.dans_stock ? "✅" : "🛒"}</span>
                  <span style={{ flex: 1, fontSize: 14, color: T.text, fontWeight: 500 }}>{ing.nom}</span>
                  <span style={{ fontSize: 13, color: T.t2 }}>{ing.quantite}</span>
                </div>
              ))}
              {(mealRecipe.ingredients || []).some(i => !i.dans_stock) && (
                <button onClick={() => { (mealRecipe.ingredients || []).filter(i => !i.dans_stock).forEach(ing => addShop(ing.nom)); setActiveMeal(null); setMealRecipe(null); }}
                  style={{ marginTop: 12, padding: "10px 16px", borderRadius: 12, border: "none", cursor: "pointer", background: T.blueBg, color: T.blue, fontWeight: 700, fontSize: 13 }}>
                  🛒 Ajouter les manquants aux courses
                </button>
              )}
            </div>
            <SL>Étapes</SL>
            {(mealRecipe.etapes || []).map((step, i) => (
              <div key={i} style={{ display: "flex", gap: 14, marginBottom: 14 }}>
                <span style={{ width: 24, height: 24, borderRadius: 8, background: T.accent, color: "#fff", fontWeight: 800, fontSize: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2 }}>{i + 1}</span>
                <span style={{ fontSize: 14, color: T.text, lineHeight: 1.65 }}>{step}</span>
              </div>
            ))}
            {mealRecipe.conseil && (
              <div style={{ marginTop: 16, padding: "16px", borderRadius: 16, background: T.accentBg }}>
                <div style={{ fontSize: 11, fontWeight: 800, color: T.accentDk, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 }}>💡 Conseil nutrition</div>
                <div style={{ fontSize: 13, color: T.t2, lineHeight: 1.6 }}>{mealRecipe.conseil}</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );

  // ── HOME ───────────────────────────────────────────────────────────────────
  const HomePage = () => {
    const h = new Date().getHours();
    const greet = h < 12 ? "Bonjour" : h < 18 ? "Bon après-midi" : "Bonsoir";
    return (
      <div style={{ padding: "0 20px 32px" }}>
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 14, color: T.t2, fontWeight: 600, marginBottom: 2 }}>{greet},</div>
          <div style={{ fontFamily: "Georgia, 'Times New Roman', serif", fontSize: 38, fontWeight: 900, color: T.text, letterSpacing: "-0.5px", lineHeight: 1.1 }}>{data.profile} 👋</div>
          <div style={{ fontSize: 13, color: T.t3, marginTop: 6 }}>{data.items.length} aliment{data.items.length !== 1 ? "s" : ""} · {data.shopping.filter(i => !i.checked).length} courses</div>
        </div>

        <VoicePanel />

        {alerts.length > 0 && (
          <div style={{ marginBottom: 24 }}>
            <SL>⚠️ Alertes stock</SL>
            {alerts.map(item => (
              <div key={item.id} style={{ background: dark ? "#221800" : "#FFF8EE", borderRadius: 18, padding: "14px 18px", marginBottom: 10, display: "flex", alignItems: "center", gap: 12, border: `1px solid rgba(217,96,32,0.2)` }}>
                <span style={{ fontSize: 26 }}>{getcat(item.category).icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, color: T.text }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: T.orange, marginTop: 2, fontWeight: 600 }}>{item.dl === 0 ? "Épuisé aujourd'hui !" : `Dans ${item.dl} jour${item.dl > 1 ? "s" : ""}`}</div>
                </div>
                <button onClick={() => addShop(item.name)} style={{ padding: "8px 14px", borderRadius: 12, border: "none", cursor: "pointer", background: T.accentBg, color: T.accentDk, fontWeight: 700, fontSize: 13 }}>+ Courses</button>
              </div>
            ))}
          </div>
        )}

        <div style={{ marginBottom: 24 }}>
          <SL>🍽️ Ce soir, on mange quoi ?</SL>
          {meals.length === 0 ? (
            <button onClick={async () => { setMealsLoading(true); setMeals([]); try { const r = await aiJSON(`Chef cuisinier. 3 idées repas ce soir. JSON uniquement.\nFormat: {"ideas":[{"titre":"...","emoji":"...","temps":"...","difficulte":"facile|moyen","description":"..."}]}`, `Stock: ${summary()}. 3 repas variés équilibrés.`); setMeals(r.ideas || []); setMealIdx(0); } catch {} setMealsLoading(false); }}
              disabled={mealsLoading} style={{ width: "100%", padding: "18px 20px", borderRadius: 20, border: "none", cursor: mealsLoading ? "wait" : "pointer", background: mealsLoading ? T.s2 : `linear-gradient(135deg, #D96020, #A83808)`, color: mealsLoading ? T.t2 : "#fff", fontWeight: 800, fontSize: 16, fontFamily: "Georgia, serif", boxShadow: mealsLoading ? "none" : "0 8px 24px rgba(217,96,32,0.38)", display: "flex", alignItems: "center", justifyContent: "center", gap: 10 }}>
              {mealsLoading ? "⏳ Je cherche des idées…" : <><span style={{ fontSize: 22 }}>✨</span> Inspire-moi pour ce soir</>}
            </button>
          ) : (
            <div>
              <div style={{ display: "flex", justifyContent: "center", gap: 6, marginBottom: 14 }}>
                {meals.map((_, i) => <button key={i} onClick={() => setMealIdx(i)} style={{ width: i === mealIdx ? 22 : 7, height: 7, borderRadius: 4, border: "none", cursor: "pointer", background: i === mealIdx ? T.orange : T.s3, padding: 0, transition: "all 0.2s" }} />)}
              </div>
              {meals[mealIdx] && (() => {
                const m = meals[mealIdx];
                return (
                  <RCard>
                    <div style={{ height: 156, background: dark ? "#1E1400" : "#FFF4E4", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 84, position: "relative" }}>
                      <span style={{ filter: "drop-shadow(0 6px 16px rgba(0,0,0,0.1))" }}>{m.emoji}</span>
                      <div style={{ position: "absolute", top: 12, right: 12, background: "rgba(0,0,0,0.22)", color: "#fff", padding: "4px 12px", borderRadius: 20, fontSize: 11, fontWeight: 700, backdropFilter: "blur(8px)" }}>{m.temps} · {m.difficulte}</div>
                    </div>
                    <div style={{ padding: "16px 18px" }}>
                      <div style={{ fontFamily: "Georgia, serif", fontWeight: 800, fontSize: 18, color: T.text, marginBottom: 6 }}>{m.titre}</div>
                      <div style={{ fontSize: 13, color: T.t2, lineHeight: 1.55, marginBottom: 14 }}>{m.description}</div>
                      <div style={{ display: "flex", gap: 10 }}>
                        <button onClick={() => setMealIdx((mealIdx + 1) % meals.length)} style={{ flex: 1, padding: "12px", borderRadius: 14, border: `1px solid ${T.border}`, background: T.s2, color: T.t2, fontWeight: 700, fontSize: 13, cursor: "pointer" }}>Suivant →</button>
                        <button onClick={async () => { setActiveMeal(m); setMealRecipe(null); setMealRecipeLoading(true); try { const r = await aiJSON(`Chef nutritionniste. JSON uniquement.\nFormat: {"titre":"...","temps":"...","equilibre":{"proteines":"...","glucides":"...","lipides":"..."},"ingredients":[{"nom":"...","quantite":"...","dans_stock":true}],"etapes":["..."],"conseil":"..."}`, `Recette: ${m.titre}\nStock: ${summary()}\nPersonnes: 2\nType: rapide`); setMealRecipe(r); } catch { setMealRecipe({ error: true }); } setMealRecipeLoading(false); }}
                          style={{ flex: 2, padding: "12px", borderRadius: 14, border: "none", cursor: "pointer", background: `linear-gradient(135deg, #D96020, #A83808)`, color: "#fff", fontWeight: 800, fontSize: 13, boxShadow: "0 4px 14px rgba(217,96,32,0.35)" }}>Voir la recette</button>
                      </div>
                    </div>
                  </RCard>
                );
              })()}
              <button onClick={() => setMeals([])} style={{ marginTop: 10, width: "100%", padding: 9, borderRadius: 10, border: "none", background: "transparent", color: T.t2, fontSize: 13, cursor: "pointer" }}>↺ Regénérer</button>
            </div>
          )}
        </div>

        <SL>Répartition</SL>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
          {STORAGES.map(s => (
            <button key={s.id} onClick={() => { setStor(s.id); setTab("stock"); }} style={{ padding: "16px 8px", borderRadius: 18, border: `1px solid ${T.border}`, background: T.surface, cursor: "pointer", textAlign: "center", boxShadow: T.sh }}>
              <div style={{ fontSize: 24 }}>{s.icon}</div>
              <div style={{ fontSize: 22, fontWeight: 900, color: T.text, marginTop: 6, fontFamily: "Georgia, serif" }}>{data.items.filter(i => i.storage === s.id).length}</div>
              <div style={{ fontSize: 11, color: T.t2, marginTop: 2, fontWeight: 600 }}>{s.label}</div>
            </button>
          ))}
        </div>
        <style>{`@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}`}</style>
      </div>
    );
  };

  // ── STOCK ──────────────────────────────────────────────────────────────────
  const StockPage = () => (
    <div style={{ padding: "0 20px 32px" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        {STORAGES.map(s => (
          <button key={s.id} onClick={() => { setStor(s.id); setFcat("all"); }} style={{ flex: 1, padding: "12px 4px", borderRadius: 14, border: `2px solid`, borderColor: stor === s.id ? T.accent : T.border, background: stor === s.id ? T.accentBg : T.surface, color: stor === s.id ? T.accentDk : T.t2, fontWeight: 800, fontSize: 12, cursor: "pointer", transition: "all 0.15s" }}>{s.icon}<br />{s.label}</button>
        ))}
      </div>
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 16, paddingBottom: 4 }}>
        {[{ id: "all", label: "Tout", icon: "◎" }, ...CATS].map(c => (
          <button key={c.id} onClick={() => setFcat(c.id)} style={{ padding: "7px 14px", borderRadius: 20, border: "none", cursor: "pointer", fontSize: 12, fontWeight: 700, flexShrink: 0, background: fcat === c.id ? (c.accent || T.accent) : T.s2, color: fcat === c.id ? "#fff" : T.t2, transition: "all 0.15s" }}>
            {c.icon} {c.label}
          </button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "44px 20px", color: T.t2, background: T.surface, borderRadius: 20, border: `2px dashed ${T.border}` }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>🕳️</div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>Rien ici pour l'instant</div>
          </div>
        ) : filtered.map(item => {
          const c = getcat(item.category);
          const dl = daysLeft(item);
          return (
            <RCard key={item.id}>
              <div style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, flexShrink: 0, background: dark ? c.dark : c.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>{c.icon}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, color: T.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.name}</div>
                  <div style={{ display: "flex", gap: 6, marginTop: 3, alignItems: "center" }}>
                    <span style={{ fontSize: 12, color: T.t2 }}>{c.label} · {item.quantity}</span>
                    {dl !== null && <span style={{ fontSize: 11, fontWeight: 800, color: dl <= 1 ? T.red : dl <= 3 ? T.orange : T.accent, background: dl <= 1 ? "rgba(208,48,40,0.1)" : dl <= 3 ? T.orangeBg : T.accentBg, padding: "2px 7px", borderRadius: 8 }}>J-{dl}</span>}
                  </div>
                </div>
                <button onClick={() => removeItem(item.id)} style={{ width: 30, height: 30, borderRadius: 9, border: "none", cursor: "pointer", background: dark ? "rgba(208,48,40,0.15)" : "rgba(208,48,40,0.08)", color: T.red, fontSize: 18, display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
              </div>
            </RCard>
          );
        })}
      </div>
      {!showAdd ? (
        <button onClick={() => { setShowAdd(true); setNewItem(n => ({ ...n, storage: stor })); }} style={{ width: "100%", padding: 15, borderRadius: 18, border: `2px dashed ${T.accent}`, background: T.accentBg, color: T.accentDk, fontWeight: 800, fontSize: 15, cursor: "pointer" }}>+ Ajouter manuellement</button>
      ) : (
        <RCard style={{ padding: 18 }}>
          <input value={newItem.name} onChange={e => setNewItem(n => ({ ...n, name: e.target.value }))} onKeyDown={e => e.key === "Enter" && addItem()} placeholder="Nom de l'aliment…" autoFocus
            style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `2px solid ${T.border}`, background: T.s2, color: T.text, fontSize: 15, outline: "none", marginBottom: 12, boxSizing: "border-box" }} />
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            <select value={newItem.category} onChange={e => setNewItem(n => ({ ...n, category: e.target.value }))} style={{ flex: 1, padding: "10px 8px", borderRadius: 12, border: `2px solid ${T.border}`, background: T.s2, color: T.text, fontSize: 13 }}>
              {CATS.map(c => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
            </select>
            <select value={newItem.quantity} onChange={e => setNewItem(n => ({ ...n, quantity: e.target.value }))} style={{ flex: 1, padding: "10px 8px", borderRadius: 12, border: `2px solid ${T.border}`, background: T.s2, color: T.text, fontSize: 13 }}>
              {QTYS.map(q => <option key={q} value={q}>{q}</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, color: T.t2, marginBottom: 6, fontWeight: 600 }}>Date de fin estimée (alertes J-4)</div>
            <input type="date" value={newItem.emptyDate} onChange={e => setNewItem(n => ({ ...n, emptyDate: e.target.value }))}
              style={{ width: "100%", padding: "10px 12px", borderRadius: 12, border: `2px solid ${T.border}`, background: T.s2, color: T.text, fontSize: 13, boxSizing: "border-box" }} />
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => setShowAdd(false)} style={{ flex: 1, padding: 12, borderRadius: 14, border: "none", cursor: "pointer", background: T.s2, color: T.t2, fontWeight: 700, fontSize: 14 }}>Annuler</button>
            <button onClick={addItem} style={{ flex: 2, padding: 12, borderRadius: 14, border: "none", cursor: "pointer", background: "linear-gradient(135deg, #4CAF6F, #2A7040)", color: "#fff", fontWeight: 800, fontSize: 14, boxShadow: "0 4px 12px rgba(76,175,111,0.4)" }}>Ajouter</button>
          </div>
        </RCard>
      )}
    </div>
  );

  // ── RECETTES ───────────────────────────────────────────────────────────────
  const RecettesPage = () => (
    <div style={{ padding: "0 20px 32px" }}>
      <RCard style={{ padding: 18, marginBottom: 16 }}>
        <div style={{ display: "flex", gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: T.t2, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.08em" }}>Personnes</div>
            <div style={{ display: "flex", gap: 6 }}>
              {[1, 2, 3, 4].map(n => <button key={n} onClick={() => setRPersons(n)} style={{ flex: 1, padding: "10px 0", borderRadius: 12, border: "none", cursor: "pointer", background: rPersons === n ? T.accent : T.s2, color: rPersons === n ? "#fff" : T.t2, fontWeight: 800, fontSize: 15, transition: "all 0.15s" }}>{n}</button>)}
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: T.t2, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.08em" }}>Type</div>
            <div style={{ display: "flex", gap: 6 }}>
              {["rapide", "élaboré"].map(t => <button key={t} onClick={() => setRType(t)} style={{ flex: 1, padding: "10px 4px", borderRadius: 12, border: "none", cursor: "pointer", background: rType === t ? T.accent : T.s2, color: rType === t ? "#fff" : T.t2, fontWeight: 700, fontSize: 12, transition: "all 0.15s" }}>{t}</button>)}
            </div>
          </div>
        </div>
      </RCard>
      <button onClick={async () => { setRLoading(true); setRRecipe(null); try { const r = await aiJSON(`Chef nutritionniste. JSON uniquement.\nFormat: {"titre":"...","temps":"...","equilibre":{"proteines":"...","glucides":"...","lipides":"..."},"ingredients":[{"nom":"...","quantite":"...","dans_stock":true}],"etapes":["..."],"conseil":"..."}`, `Stock: ${summary()}\nPersonnes: ${rPersons}\nType: ${rType}`); setRRecipe(r); } catch { setRRecipe({ error: true }); } setRLoading(false); }}
        disabled={rLoading} style={{ width: "100%", padding: 16, borderRadius: 18, border: "none", cursor: rLoading ? "wait" : "pointer", background: rLoading ? T.s2 : "linear-gradient(135deg, #4CAF6F, #2A7040)", color: rLoading ? T.t2 : "#fff", fontWeight: 800, fontSize: 16, fontFamily: "Georgia, serif", marginBottom: 20, boxShadow: rLoading ? "none" : "0 6px 18px rgba(76,175,111,0.4)", transition: "all 0.2s" }}>
        {rLoading ? "⏳ Génération…" : "✨ Générer une recette"}
      </button>
      {rRecipe && !rRecipe.error && (
        <RCard>
          <div style={{ padding: "18px 18px 14px", background: T.accentBg, borderBottom: `1px solid ${T.border}` }}>
            <div style={{ fontFamily: "Georgia, serif", fontWeight: 800, fontSize: 20, color: T.text, marginBottom: 4 }}>{rRecipe.titre}</div>
            <div style={{ fontSize: 13, color: T.t2 }}>⏱ {rRecipe.temps} · {rPersons} pers.</div>
          </div>
          {rRecipe.equilibre && (
            <div style={{ display: "flex", borderBottom: `1px solid ${T.border}` }}>
              {Object.entries(rRecipe.equilibre).map(([k, v], i, arr) => (
                <div key={k} style={{ flex: 1, padding: "12px 6px", textAlign: "center", borderRight: i < arr.length - 1 ? `1px solid ${T.border}` : "none" }}>
                  <div style={{ fontSize: 10, fontWeight: 800, color: T.accent, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 4 }}>{k}</div>
                  <div style={{ fontSize: 12, color: T.t2 }}>{v}</div>
                </div>
              ))}
            </div>
          )}
          <div style={{ padding: "16px 18px", borderBottom: `1px solid ${T.border}` }}>
            <SL>Ingrédients</SL>
            {(rRecipe.ingredients || []).map((ing, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <span style={{ fontSize: 16 }}>{ing.dans_stock ? "✅" : "🛒"}</span>
                <span style={{ flex: 1, fontSize: 14, color: T.text, fontWeight: 500 }}>{ing.nom}</span>
                <span style={{ fontSize: 13, color: T.t2 }}>{ing.quantite}</span>
              </div>
            ))}
            {(rRecipe.ingredients || []).some(i => !i.dans_stock) && (
              <button onClick={() => (rRecipe.ingredients || []).filter(i => !i.dans_stock).forEach(ing => addShop(ing.nom))}
                style={{ marginTop: 8, padding: "10px 16px", borderRadius: 12, border: "none", cursor: "pointer", background: T.blueBg, color: T.blue, fontWeight: 700, fontSize: 13 }}>🛒 Ajouter les manquants aux courses</button>
            )}
          </div>
          <div style={{ padding: "16px 18px" }}>
            <SL>Étapes</SL>
            {(rRecipe.etapes || []).map((step, i) => (
              <div key={i} style={{ display: "flex", gap: 14, marginBottom: 14 }}>
                <span style={{ width: 24, height: 24, borderRadius: 8, background: T.accent, color: "#fff", fontWeight: 800, fontSize: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2 }}>{i + 1}</span>
                <span style={{ fontSize: 14, color: T.text, lineHeight: 1.6 }}>{step}</span>
              </div>
            ))}
            {rRecipe.conseil && (
              <div style={{ marginTop: 14, padding: "14px", borderRadius: 14, background: T.accentBg }}>
                <div style={{ fontSize: 11, fontWeight: 800, color: T.accentDk, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 }}>💡 Conseil</div>
                <div style={{ fontSize: 13, color: T.t2, lineHeight: 1.6 }}>{rRecipe.conseil}</div>
              </div>
            )}
          </div>
        </RCard>
      )}
    </div>
  );

  // ── COURSES ────────────────────────────────────────────────────────────────
  const CoursesPage = () => (
    <div style={{ padding: "0 20px 32px" }}>
      <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
        <input value={shopInput} onChange={e => setShopInput(e.target.value)} onKeyDown={e => e.key === "Enter" && addShop()} placeholder="Ajouter un article…"
          style={{ flex: 1, padding: "13px 16px", borderRadius: 16, border: `2px solid ${T.border}`, background: T.surface, color: T.text, fontSize: 15, outline: "none", boxShadow: T.sh }} />
        <button onClick={() => addShop()} style={{ padding: "13px 20px", borderRadius: 16, border: "none", cursor: "pointer", background: "linear-gradient(135deg, #4CAF6F, #2A7040)", color: "#fff", fontWeight: 800, fontSize: 22, boxShadow: "0 4px 12px rgba(76,175,111,0.4)" }}>+</button>
      </div>
      <button onClick={async () => { setShopSuggLoading(true); try { const r = await aiJSON(`JSON uniquement. Format: {"suggestions":["item1",...]} max 8.`, `Stock: ${data.items.map(i => i.name).join(", ") || "vide"}. Courses semaine équilibrée.`, 400); setShopSugg(r.suggestions || []); } catch {} setShopSuggLoading(false); }}
        disabled={shopSuggLoading} style={{ width: "100%", padding: 14, borderRadius: 16, border: "none", cursor: shopSuggLoading ? "wait" : "pointer", background: T.blueBg, color: T.blue, fontWeight: 800, fontSize: 14, marginBottom: 16 }}>
        {shopSuggLoading ? "⏳ Analyse…" : "✨ Suggestions IA pour la semaine"}
      </button>
      {shopSugg.length > 0 && (
        <div style={{ marginBottom: 20 }}>
          <SL>Suggestions IA</SL>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {shopSugg.map((s, i) => <button key={i} onClick={() => addShop(s)} style={{ padding: "8px 16px", borderRadius: 20, border: `2px solid ${T.blue}30`, background: T.blueBg, color: T.blue, fontSize: 13, fontWeight: 700, cursor: "pointer" }}>+ {s}</button>)}
          </div>
        </div>
      )}
      <SL>{data.shopping.filter(i => !i.checked).length} article{data.shopping.filter(i => !i.checked).length !== 1 ? "s" : ""} restant{data.shopping.filter(i => !i.checked).length !== 1 ? "s" : ""}</SL>
      {data.shopping.length === 0 ? (
        <div style={{ textAlign: "center", padding: "44px 20px", color: T.t2, background: T.surface, borderRadius: 20, boxShadow: T.sh }}>
          <div style={{ fontSize: 36, marginBottom: 10 }}>🛒</div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Liste vide</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {data.shopping.map(item => (
            <RCard key={item.id}>
              <div style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 12, opacity: item.checked ? 0.38 : 1, transition: "opacity 0.2s" }}>
                <button onClick={() => toggleShop(item.id)} style={{ width: 26, height: 26, borderRadius: 8, border: `2.5px solid`, borderColor: item.checked ? T.accent : T.border, background: item.checked ? T.accent : "transparent", cursor: "pointer", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 14, fontWeight: 800 }}>{item.checked ? "✓" : ""}</button>
                <span style={{ flex: 1, fontSize: 15, fontWeight: 600, color: T.text, textDecoration: item.checked ? "line-through" : "none" }}>{item.name}</span>
                <button onClick={() => removeShop(item.id)} style={{ width: 30, height: 30, borderRadius: 9, border: "none", cursor: "pointer", background: dark ? "rgba(208,48,40,0.15)" : "rgba(208,48,40,0.08)", color: T.red, fontSize: 18, display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
              </div>
            </RCard>
          ))}
          {data.shopping.some(i => i.checked) && (
            <button onClick={() => setData(d => ({ ...d, shopping: d.shopping.filter(i => !i.checked) }))} style={{ padding: 12, borderRadius: 14, border: "none", cursor: "pointer", background: dark ? "rgba(208,48,40,0.1)" : "rgba(208,48,40,0.07)", color: T.red, fontWeight: 700, fontSize: 13, marginTop: 4 }}>🗑️ Supprimer les cochés</button>
          )}
        </div>
      )}
    </div>
  );

  // ── TABS ───────────────────────────────────────────────────────────────────
  const TABS = [
    { id: "home",     icon: "🏠", label: "Home" },
    { id: "stock",    icon: "🧺", label: "Mon Stock" },
    { id: "recettes", icon: "🍽️", label: "Recettes" },
    { id: "courses",  icon: "🛒", label: "Courses" },
  ];

  // ── RENDER ─────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: "100vh", background: T.bg, color: T.text, fontFamily: "-apple-system, 'SF Pro Text', 'Helvetica Neue', sans-serif", paddingBottom: 90, transition: "background 0.3s, color 0.3s" }}>
      {showConsumeModal && <ConsumeModal />}
      {activeMeal && <MealModal />}

      {/* Header */}
      <div style={{ position: "sticky", top: 0, zIndex: 100, background: dark ? "rgba(18,16,14,0.9)" : "rgba(250,247,242,0.9)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)", borderBottom: `1px solid ${T.border}`, padding: "13px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 10, background: "linear-gradient(145deg, #4CAF6F, #2A7040)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, boxShadow: "0 3px 10px rgba(76,175,111,0.4)" }}>🍃</div>
          <div>
            <div style={{ fontFamily: "Georgia, serif", fontWeight: 800, fontSize: 17, color: T.text, lineHeight: 1 }}>Llo Kitchen</div>
            {alerts.length > 0 && <div style={{ fontSize: 10, color: T.orange, fontWeight: 700, marginTop: 1 }}>⚠️ {alerts.length} alerte{alerts.length > 1 ? "s" : ""}</div>}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={() => { setData(d => ({ ...d, profile: null })); setShowOnboard(true); }} style={{ fontSize: 11, padding: "5px 10px", borderRadius: 10, border: `1px solid ${T.border}`, background: T.s2, color: T.t2, fontWeight: 600, cursor: "pointer" }}>👤 {data.profile}</button>
          <button onClick={cycleTheme} style={{ width: 34, height: 34, borderRadius: 10, border: `1px solid ${T.border}`, background: T.s2, cursor: "pointer", fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center" }}>{dark ? "☀️" : "🌙"}</button>
        </div>
      </div>

      {/* Page title */}
      <div style={{ padding: "20px 20px 10px" }}>
        <h1 style={{ fontFamily: "Georgia, 'Times New Roman', serif", fontSize: 28, fontWeight: 900, margin: 0, letterSpacing: "-0.3px", color: T.text }}>
          {tab === "home" && `${new Date().getHours() < 12 ? "Bonjour" : new Date().getHours() < 18 ? "Bon après-midi" : "Bonsoir"}, ${data.profile} 👋`}
          {tab === "stock" && "Mon Stock"}
          {tab === "recettes" && "Recettes"}
          {tab === "courses" && "Courses"}
        </h1>
      </div>

      {tab === "home" && <HomePage />}
      {tab === "stock" && <StockPage />}
      {tab === "recettes" && <RecettesPage />}
      {tab === "courses" && <CoursesPage />}

      {/* Bottom nav */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 100, background: dark ? "rgba(18,16,14,0.95)" : "rgba(250,247,242,0.95)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)", borderTop: `1px solid ${T.border}`, display: "flex", padding: "8px 8px 24px", gap: 4 }}>
        {TABS.map(t => {
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ flex: 1, padding: "8px 4px 6px", borderRadius: 14, border: "none", cursor: "pointer", background: active ? T.accentBg : "transparent", color: active ? T.accentDk : T.t2, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, transition: "all 0.15s" }}>
              <span style={{ fontSize: 20 }}>{t.icon}</span>
              <span style={{ fontSize: 10, fontWeight: active ? 800 : 500 }}>{t.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
